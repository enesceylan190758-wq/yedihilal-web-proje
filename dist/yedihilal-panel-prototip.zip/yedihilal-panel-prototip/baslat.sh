#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Panel: http://localhost:8080/panel/"
echo "Durdurmak için Ctrl+C"
python3 -m http.server 8080
