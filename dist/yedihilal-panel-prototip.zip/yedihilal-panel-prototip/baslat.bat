@echo off
cd /d "%~dp0"
echo Panel: http://localhost:8080/panel/
echo Durdurmak icin Ctrl+C
py -m http.server 8080
if errorlevel 1 python -m http.server 8080
pause
